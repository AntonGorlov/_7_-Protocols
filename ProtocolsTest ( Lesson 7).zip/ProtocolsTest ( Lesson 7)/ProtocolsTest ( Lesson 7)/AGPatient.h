//
//  AGPatient.h
//  ProtocolsTest ( Lesson 7)
//
//  Created by Anton Gorlov on 28.09.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol AGPatient <NSObject>
@required //все что ниже списка -обязательно

@property (strong, nonatomic) NSString* name;

-(bool) areYouOk;
-(void) takePill;
-(void) makeshot; //кушай таблетку

@optional
-(NSString*) howIsYourFamily;
-(NSString*) howIsYourJob;
@end
