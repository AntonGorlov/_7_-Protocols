//
//  AppDelegate.m
//  ProtocolsTest ( Lesson 7)
//
//  Created by Anton Gorlov on 24.09.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AppDelegate.h"
#import "AGStudent.h"
#import "AGDancer.h"
#import "AGGrandmother.h"
#import "AGPatient.h" //Наш созданный протокол.
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    
    
    AGStudent* student1=[[AGStudent alloc]init];
    AGStudent* student2=[[AGStudent alloc]init];
    AGStudent* student3=[[AGStudent alloc]init];

    
    AGDancer* dancer1=[[AGDancer alloc]init];
    AGDancer* dancer2=[[AGDancer alloc]init];
    
    AGGrandmother* grandmother1=[[AGGrandmother alloc]init];
    NSObject* fake=[[NSObject alloc]init];//создадим обьект,чтобы проверить,если в массиве окажиться не пациент (Без параметров протокола  <AGPatient> в хедере).
    
    NSArray* patients=[NSArray arrayWithObjects:fake,student1,student2,student3,dancer1,dancer2,grandmother1, nil];
    
    student1.name=@"student1"; //устанавливаем параметры.
    [student2 setName:@"student2"];//устанавливаем через сеттер.
    [student3 setName:@"Student3"];
    
    dancer1.name=@"dancer1";
    [dancer2 setName:@"dancer2"];
    
    grandmother1.name=@"grandmother";
    
    //реализуем процедуру лечения в нутри цикла for.
    
    for (id <AGPatient> hospital in patients){
        
        if ([hospital conformsToProtocol:@protocol(AGPatient)]) {//проверка,есть ли в массиве не пациент.
            NSLog(@"patient name - %@", hospital.name);
            if ([hospital respondsToSelector:@selector(howIsYourFamily)]) {//название переменной цикла for,метод NSObject, @selector()-указатель на наш метод.Если отвечает селектор,то спросим,есть ли этот метод у класса.
                NSLog(@"How is your family? \n%@",[hospital howIsYourFamily]);//реализуем опциональный метод
            }
            if ([hospital respondsToSelector:@selector(howIsYourJob)]) {
                NSLog(@"How is your job? \n%@",[hospital howIsYourJob]);
            }
            
            
            if (![hospital areYouOk]) { // !-обозначает обратное действие
                [hospital takePill];
                if (![hospital areYouOk]) {
                    [hospital makeshot];
                }
            }

        } else {
            NSLog(@"FAKE!!!!");
        }
        
            }
    
    
    //или
/* for (NSInteger i=0; i<[patients count];i++) {
        id <AGPatient>patient [patients objectAtIndex:i];
    }
 */
    
    
    
    
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
