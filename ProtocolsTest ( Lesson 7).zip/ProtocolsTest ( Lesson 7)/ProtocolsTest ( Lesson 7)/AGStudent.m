//
//  AGStudent.m
//  ProtocolsTest ( Lesson 7)
//
//  Created by Anton Gorlov on 28.09.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGStudent.h"

@implementation AGStudent
#pragma mark --AGPatient

-(void) study { }

-(bool) areYouOk {
    bool ok= arc4random() % 2;
    NSLog(@"Is  %@ ok? %@",self.name,ok?@"Yes":@"No");
    return ok;

}
-(void) takePill {
    NSLog(@" %@ takes a pill",self.name);
}
-(void) makeshot {
    NSLog(@"%@ makes a shot", self.name);
}

-(NSString*) howIsYourFamily { // в header необязательно добавлять (приватный метод)
    return @"My family is doing well!!";
}
@end
