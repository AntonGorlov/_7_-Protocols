//
//  AGStudent.h
//  ProtocolsTest ( Lesson 7)
//
//  Created by Anton Gorlov on 28.09.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AGPatient.h"
@interface AGStudent : NSObject <AGPatient>
@property (strong, nonatomic) NSString* universityName;
@property (strong,nonatomic)  NSString* name;
-(void) study;
@end
