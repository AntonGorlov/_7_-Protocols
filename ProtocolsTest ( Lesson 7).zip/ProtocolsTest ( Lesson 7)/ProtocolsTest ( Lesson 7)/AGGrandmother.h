//
//  AGGrandmother.h
//  ProtocolsTest ( Lesson 7)
//
//  Created by Anton Gorlov on 28.09.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AGPatient.h"
@interface AGGrandmother : NSObject <AGPatient> //если пишем <AGPatient>,то этот класс соглашаеться выполнить обязательные требования и не об требования протокола.

@property (assign,nonatomic) float* experiens;
@property (strong,nonatomic) NSString*name;
-(void) work;
@end
