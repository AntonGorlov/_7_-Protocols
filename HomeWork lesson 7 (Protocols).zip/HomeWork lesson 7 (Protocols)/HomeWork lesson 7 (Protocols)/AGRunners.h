//
//  AGRunners.h
//  HomeWork lesson 7 (Protocols)
//
//  Created by Anton Gorlov on 30.09.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol AGRunners <NSObject>

@required
@property (strong,nonatomic) NSString* name;
@property (assign,nonatomic) NSString* lastName;
@property (assign,nonatomic) NSInteger length;//бег в длину
-(void) runners;
-(void) trainingRunners;
@optional
-(void) driving;
-(NSString*) football;
@end
