//
//  AGPeople2.h
//  HomeWork lesson 7 (Protocols)
//
//  Created by Anton Gorlov on 30.09.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AGSwimmers.h"
@interface AGPeople2 : NSObject <AGSwimmers>
@property (strong,nonatomic) NSString* name;
@property (assign,nonatomic) NSString* lastName;
@property (assign,nonatomic) NSInteger length;//плаванье в длину
@end
