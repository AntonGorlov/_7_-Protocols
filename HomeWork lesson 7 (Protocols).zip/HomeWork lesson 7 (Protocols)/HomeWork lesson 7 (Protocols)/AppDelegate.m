//
//  AppDelegate.m
//  HomeWork lesson 7 (Protocols)
//
//  Created by Anton Gorlov on 30.09.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AppDelegate.h"
#import "AGJumpers.h"
#import "AGPeople1.h"
#import "AGSwimmers.h"
#import "AGPeople2.h"
#import "AGRunners.h"
#import "AGPeople3.h"
#import "AGPeople4.h"
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    AGPeople1* people1=[[AGPeople1 alloc]init];
    AGPeople2* people2=[[AGPeople2 alloc]init];
    AGPeople3* people3=[[AGPeople3 alloc]init];
    AGPeople4* people4=[[AGPeople4 alloc]init];
 
    
    
 
    
    people1.name=@"Sergey";
    people1.lastName=@"Bubka";
    people1.height=9.53f;
    
    people2.name=@"Denis";
    people2.lastName=@"Selantiev";
    people2.length=50;
    
    [people3 setName:@"Usain"];
    [people3 setLastName:@"Bolt"];
    [people3 setLength:3];
    
    [people4 setName:@"Iulius"];
    people4.lastName=@"Caesar";
    people4.height=9.20f;
    people4.length=100;
    people4.lengthRun=12;
    
    
    
    
    
    
    
    NSArray* stars = [NSArray arrayWithObjects:people1,people2,people3,people4, nil];
    
    for (id <AGJumpers,AGRunners,AGSwimmers> sportman in stars) {
         NSLog(@"\n %@ %@",sportman.name,sportman.lastName);
        
        
        if ([sportman conformsToProtocol:@protocol(AGJumpers)]) { //реализован ли протокол или нет (проверка на то что в  классе PEOPLE1 реализовано AGPeople1 : NSObject <AGJumpers> )
         [sportman jumping];
            if ([sportman respondsToSelector:@selector(developing)]) { //если есть такой метод,то заходим.
                [sportman developing];
                NSLog(@" %@ ",[sportman developing]);
            }
        }
        
        if ([sportman conformsToProtocol:@protocol(AGRunners)]) {
            [sportman runners];
            if ([sportman respondsToSelector:@selector(flying)]) {
                [sportman flying];
                NSLog(@" %@ ",[sportman flying]);
            }
        }
       
        
        
        if ([sportman conformsToProtocol:@protocol(AGSwimmers) ]) {
             [sportman swimming];
            if ([sportman respondsToSelector:@selector(football)]) {
                [sportman football];
                NSLog(@" %@ ",[sportman football]);
            }

        }
        
    }

    
    

    
    
    
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
