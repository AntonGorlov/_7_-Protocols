//
//  AGPeople4.h
//  HomeWork lesson 7 (Protocols)
//
//  Created by Anton Gorlov on 05.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AGJumpers.h"
#import "AGRunners.h"
#import "AGSwimmers.h"
@interface AGPeople4 : NSObject <AGJumpers,AGRunners,AGSwimmers>
//Сделайте так чтобы один какой-то класс мог и бегать и прыгать и плавать и посмотрите как он себя поведет в цикле. К класса People 4 будут подключены 3 протокола.
@property (strong,nonatomic) NSString* name;
@property (assign,nonatomic) NSString* lastName;
@property (assign,nonatomic) float height;//прижки в высоту.
@property (assign,nonatomic) NSInteger length;//плаванье в длину
@property (assign,nonatomic) NSInteger lengthRun;//бег в длину

// прописывать методы (NSString *,void) в хедере не обязательно,так как в протоколе они расписаны.


@end
