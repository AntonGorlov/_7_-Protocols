//
//  AGPeople1.h
//  HomeWork lesson 7 (Protocols)
//
//  Created by Anton Gorlov on 30.09.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AGJumpers.h"
@interface AGPeople1 : NSObject <AGJumpers>
@property (strong,nonatomic) NSString* name;
@property (assign,nonatomic) NSString* lastName;
@property (assign,nonatomic) float height;//прижки в высоту.
-(void) jumping;
@end
