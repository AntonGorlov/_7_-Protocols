//
//  AGJumpers.h
//  HomeWork lesson 7 (Protocols)
//
//  Created by Anton Gorlov on 30.09.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol AGJumpers <NSObject>

@required
@property (strong,nonatomic) NSString* name;
@property (assign,nonatomic) NSString* lastName;
@property (assign,nonatomic) float height;//прижки в высоту.
-(void) jumping;
-(void) trainingForJumping;
@optional
-(void) driving;
-(NSString*) developing;
@end
