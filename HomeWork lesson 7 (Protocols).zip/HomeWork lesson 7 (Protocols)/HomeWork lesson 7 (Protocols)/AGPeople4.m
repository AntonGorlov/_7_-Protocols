//
//  AGPeople4.m
//  HomeWork lesson 7 (Protocols)
//
//  Created by Anton Gorlov on 05.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGPeople4.h"


@implementation AGPeople4

//ниже показаны обязательные методы (Required),если класс подписан на протокол,то прога будет думать,что мы реализовали методы.РЕАЛИЗОВАТЬ ВСЕ МЕТОДЫ ОБЯЗАТЕЛЬНО.

-(void) jumping {
    NSLog(@"%@ %@ is jumping on the horses,",self.name,self.lastName);
}

-(void) trainingForJumping {
    NSLog(@"%@ %@ is training once a week,his result:%.2f",self.name,self.lastName,self.height);
}
-(void) swimming {
    NSLog(@"%@ %@ is swimming in the big river",self.name,self.lastName);
}
-(void) trainingSwimmming {
 NSLog(@"%@ %@ is training once a month,his result:%.2ld ",self.name,self.lastName,self.length);
}

-(void) runners {
    NSLog(@"%@ %@ is runners on the road",self.name,self.lastName);
}
-(void) trainingRunners {
 NSLog(@"%@ %@ is training averyday,his result:%.2ld ",self.name,self.lastName,self.lengthRun);
}

//ниже опциональные методы,которе не обязательно выполнять.
- (NSString *) description {
    return [NSString stringWithFormat:@"firstName = %@, lastName = %@", self.name, self.lastName]; //in appdelegate вызов этого метода -NSLog(@"%@", object);
}

-(NSString*) developing{
    return @" Iulius Caesar is a great developer ";
}

-(NSString*) flying {
return @"Iulius Caesar doesn't flying";
}

-(NSString*) football {
return @"Iulius Caesar and his team are good at plaing football";
}
@end
