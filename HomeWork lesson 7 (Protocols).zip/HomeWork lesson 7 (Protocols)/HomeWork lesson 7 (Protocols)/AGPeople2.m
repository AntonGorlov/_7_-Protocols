//
//  AGPeople2.m
//  HomeWork lesson 7 (Protocols)
//
//  Created by Anton Gorlov on 30.09.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGPeople2.h"

@implementation AGPeople2

- (NSString *) description {
    return [NSString stringWithFormat:@"firstName = %@, lastName = %@", self.name, self.lastName]; //in appdelegate вызов этого метода -NSLog(@"%@", object);
}
-(void) swimming {
    NSLog(@"%@ %@ likes swimming.His result:%.ld",self.name,self.lastName,self.length);
}
-(void) trainingSwimmming {
    NSLog(@"%@ %@ is training for wins",self.name,self.lastName);
}

-(void) driving {
    NSLog(@"A car's %@ %@ doesn't fixed ",self.name,self.lastName);
}
-(NSString*) flying {
    return @"Denis Selantiev is afraid flying";
}

@end
