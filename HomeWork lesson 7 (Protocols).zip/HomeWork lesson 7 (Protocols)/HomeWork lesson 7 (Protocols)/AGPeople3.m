//
//  AGPeople3.m
//  HomeWork lesson 7 (Protocols)
//
//  Created by Anton Gorlov on 30.09.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGPeople3.h"

@implementation AGPeople3

- (NSString *) description {
    return [NSString stringWithFormat:@"firstName = %@, lastName = %@", self.name, self.lastName]; //in appdelegate вызов этого метода -NSLog(@"%@", object);
}
-(void) runners {
    NSLog(@"%@ %@ running it's life.His result length:%ld",self.name,self.lastName,(long)self.length);
}
-(void) trainingRunners {
    NSLog(@"%@ %@ needs training everyday",self.name,self.lastName);
}

-(void) driving {
    NSLog(@"%@ has a yellow camaro",self.name);
}
-(NSString*) football {
return @"footbal it's not my cup of tea";
}
@end
