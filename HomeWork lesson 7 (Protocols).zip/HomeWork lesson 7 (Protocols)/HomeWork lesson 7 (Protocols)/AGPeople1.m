//
//  AGPeople1.m
//  HomeWork lesson 7 (Protocols)
//
//  Created by Anton Gorlov on 30.09.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGPeople1.h"

@implementation AGPeople1


- (NSString *) description {
    return [NSString stringWithFormat:@"firstName = %@, lastName = %@", self.name, self.lastName]; //in appdelegate вызов этого метода -NSLog(@"%@", object);
}

-(void) jumping {
    NSLog(@"%@ %@ is a good jumper.His result:%.2f",self.name,self.lastName,self.height);
}
-(void) trainingForJumping {
    NSLog(@"%@ %@ like training everyday",self.name,self.lastName);
}

-(void) driving {
    NSLog(@"%@ %@ doesn't have a car",self.name, self.lastName);
}
-(NSString*) developing {
    return @"Sergey Bubka doesn't understand how can developing";
}

@end
